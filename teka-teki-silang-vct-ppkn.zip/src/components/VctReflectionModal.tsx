import React, { useState } from 'react';
import { Puzzle, VctReflectionOption } from '../data/types.ts';
import { Trophy, Star, ArrowRight, BookOpen, CheckCircle, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../utils/audio.ts';

interface VctReflectionModalProps {
  puzzle: Puzzle;
  score: number;
  timeSpent: number; // in seconds
  hintsUsed: number;
  onNextPuzzle: () => void;
  onClose: () => void;
  onSaveReflection: (selectedOption: VctReflectionOption) => void;
}

export const VctReflectionModal: React.FC<VctReflectionModalProps> = ({
  puzzle,
  score,
  timeSpent,
  hintsUsed,
  onNextPuzzle,
  onClose,
  onSaveReflection,
}) => {
  const [selectedOption, setSelectedOption] = useState<VctReflectionOption | null>(null);
  const [hasReflected, setHasReflected] = useState(false);

  React.useEffect(() => {
    // Launch celebratory confetti
    sound.playVictory();
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {}
  }, []);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const stars = hintsUsed === 0 ? 3 : hintsUsed <= 2 ? 2 : 1;

  const handleSelectOption = (opt: VctReflectionOption) => {
    setSelectedOption(opt);
    sound.playTap();
  };

  const handleConfirmReflection = () => {
    if (selectedOption) {
      setHasReflected(true);
      onSaveReflection(selectedOption);
      sound.playWordSuccess();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-xl my-8 bg-slate-900 border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl relative text-slate-100 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Victory Header */}
        <div className="text-center space-y-2 mb-6">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center ring-2 ring-amber-400/40">
            <Trophy className="w-8 h-8" />
          </div>

          <div className="flex justify-center gap-1.5 pt-2">
            {[1, 2, 3].map((starIdx) => (
              <Star
                key={starIdx}
                className={`w-6 h-6 ${
                  stars >= starIdx ? 'text-amber-400 fill-amber-400 animate-bounce' : 'text-slate-700'
                }`}
              />
            ))}
          </div>

          <h2 className="text-2xl font-bold text-white tracking-tight">
            Teka-Teki Silang Selesai!
          </h2>
          <p className="text-xs text-amber-400/90 font-medium">
            Tipe #{puzzle.typeNumber}: {puzzle.title}
          </p>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-3 p-3.5 bg-slate-950/60 rounded-2xl border border-slate-800 text-center mb-6">
          <div>
            <div className="text-[11px] text-slate-400">Total Skor</div>
            <div className="text-lg font-bold text-amber-400 font-mono">{score}</div>
          </div>
          <div>
            <div className="text-[11px] text-slate-400">Waktu</div>
            <div className="text-lg font-bold text-white font-mono">{formatTime(timeSpent)}</div>
          </div>
          <div>
            <div className="text-[11px] text-slate-400">Bantuan Dipakai</div>
            <div className="text-lg font-bold text-slate-300 font-mono">{hintsUsed}x</div>
          </div>
        </div>

        {/* VCT Reflection Section */}
        <div className="space-y-4 mb-6">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>Fase Klarifikasi Nilai (VCT Reflection)</span>
          </div>

          <div className="p-4 bg-slate-800/60 rounded-2xl border border-slate-700/60">
            <p className="text-sm font-medium text-white leading-relaxed mb-3">
              {puzzle.vctReflectionQuestion}
            </p>

            <div className="space-y-2">
              {puzzle.vctReflectionOptions.map((opt, idx) => {
                const isSelected = selectedOption === opt;
                return (
                  <button
                    key={idx}
                    type="button"
                    disabled={hasReflected}
                    onClick={() => handleSelectOption(opt)}
                    className={`w-full text-left p-3 rounded-xl border text-xs leading-relaxed transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-medium ring-1 ring-amber-500/40'
                        : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <span className={`w-4 h-4 mt-0.5 rounded-full border flex items-center justify-center shrink-0 ${
                        isSelected ? 'border-amber-400 bg-amber-400 text-slate-950' : 'border-slate-600'
                      }`}>
                        {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                      </span>
                      <span>{opt.text}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Reflection feedback response */}
            {selectedOption && (
              <div className="mt-3.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200/90 leading-relaxed animate-in fade-in">
                <span className="font-semibold text-amber-300 block mb-1">
                  💡 Ulasan Nilai Berdasarkan Buku:
                </span>
                {selectedOption.feedback}
              </div>
            )}
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            Tutup & Tinjau Grid
          </button>

          {!hasReflected ? (
            <button
              type="button"
              disabled={!selectedOption}
              onClick={handleConfirmReflection}
              className={`px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedOption
                  ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md font-bold'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-800'
              }`}
            >
              <CheckCircle className="w-4 h-4" />
              <span>Konfirmasi Refleksi</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onNextPuzzle}
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <span>Lanjut ke Tipe Berikutnya</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
