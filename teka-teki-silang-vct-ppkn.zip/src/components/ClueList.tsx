import React from 'react';
import { Direction, WordItem } from '../data/types.ts';
import { ArrowRight, ArrowDown, CheckCircle2, BookOpen } from 'lucide-react';

interface ClueListProps {
  acrossWords: WordItem[];
  downWords: WordItem[];
  selectedWord: WordItem | null;
  onSelectWord: (word: WordItem) => void;
  completedWordIds: Set<string>;
}

export const ClueList: React.FC<ClueListProps> = ({
  acrossWords,
  downWords,
  selectedWord,
  onSelectWord,
  completedWordIds,
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* Mendatar (Across) */}
      <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-4 shadow-sm flex flex-col">
        <div className="flex items-center gap-2 pb-3 mb-3 border-b border-slate-800">
          <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
            <ArrowRight className="w-4 h-4" />
          </div>
          <h3 className="font-bold text-sm tracking-wide uppercase text-slate-200">
            Mendatar ({acrossWords.length})
          </h3>
        </div>

        <div className="space-y-2.5 overflow-y-auto max-h-[320px] pr-1">
          {acrossWords.map((item) => {
            const isSelected = selectedWord?.id === item.id;
            const isDone = completedWordIds.has(item.id);

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectWord(item)}
                className={`w-full text-left p-2.5 rounded-xl transition-all duration-150 cursor-pointer border ${
                  isSelected
                    ? 'bg-amber-500/15 border-amber-500/60 shadow-sm ring-1 ring-amber-500/30'
                    : isDone
                    ? 'bg-slate-950/40 border-slate-800/80 opacity-75 hover:opacity-100 hover:border-slate-700'
                    : 'bg-slate-800/40 border-slate-800 hover:bg-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <span
                    className={`w-5 h-5 shrink-0 rounded flex items-center justify-center font-mono text-xs font-bold ${
                      isSelected
                        ? 'bg-amber-400 text-slate-950'
                        : isDone
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-slate-700 text-slate-300'
                    }`}
                  >
                    {item.number}
                  </span>

                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-xs leading-relaxed ${
                        isDone && !isSelected
                          ? 'line-through text-slate-400'
                          : isSelected
                          ? 'text-amber-200 font-medium'
                          : 'text-slate-200'
                      }`}
                    >
                      {item.clue}
                    </p>

                    <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-400">
                      <span className="font-mono text-slate-400 font-semibold">
                        {item.word.length} Huruf
                      </span>
                      <span>·</span>
                      <span className="truncate flex items-center gap-1 text-slate-400">
                        <BookOpen className="w-3 h-3 text-amber-500/80" />
                        {item.bookRef}
                      </span>
                      {isDone && (
                        <span className="ml-auto text-emerald-400 flex items-center gap-1 font-medium">
                          <CheckCircle2 className="w-3 h-3" />
                          Terjawab
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Menurun (Down) */}
      <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-4 shadow-sm flex flex-col">
        <div className="flex items-center gap-2 pb-3 mb-3 border-b border-slate-800">
          <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
            <ArrowDown className="w-4 h-4" />
          </div>
          <h3 className="font-bold text-sm tracking-wide uppercase text-slate-200">
            Menurun ({downWords.length})
          </h3>
        </div>

        <div className="space-y-2.5 overflow-y-auto max-h-[320px] pr-1">
          {downWords.map((item) => {
            const isSelected = selectedWord?.id === item.id;
            const isDone = completedWordIds.has(item.id);

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectWord(item)}
                className={`w-full text-left p-2.5 rounded-xl transition-all duration-150 cursor-pointer border ${
                  isSelected
                    ? 'bg-amber-500/15 border-amber-500/60 shadow-sm ring-1 ring-amber-500/30'
                    : isDone
                    ? 'bg-slate-950/40 border-slate-800/80 opacity-75 hover:opacity-100 hover:border-slate-700'
                    : 'bg-slate-800/40 border-slate-800 hover:bg-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <span
                    className={`w-5 h-5 shrink-0 rounded flex items-center justify-center font-mono text-xs font-bold ${
                      isSelected
                        ? 'bg-amber-400 text-slate-950'
                        : isDone
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-slate-700 text-slate-300'
                    }`}
                  >
                    {item.number}
                  </span>

                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-xs leading-relaxed ${
                        isDone && !isSelected
                          ? 'line-through text-slate-400'
                          : isSelected
                          ? 'text-amber-200 font-medium'
                          : 'text-slate-200'
                      }`}
                    >
                      {item.clue}
                    </p>

                    <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-400">
                      <span className="font-mono text-slate-400 font-semibold">
                        {item.word.length} Huruf
                      </span>
                      <span>·</span>
                      <span className="truncate flex items-center gap-1 text-slate-400">
                        <BookOpen className="w-3 h-3 text-amber-500/80" />
                        {item.bookRef}
                      </span>
                      {isDone && (
                        <span className="ml-auto text-emerald-400 flex items-center gap-1 font-medium">
                          <CheckCircle2 className="w-3 h-3" />
                          Terjawab
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
