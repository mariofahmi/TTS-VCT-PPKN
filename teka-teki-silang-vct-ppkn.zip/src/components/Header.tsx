import React from 'react';
import { Volume2, VolumeX, Sparkles, BookOpen, RotateCcw } from 'lucide-react';
import { sound } from '../utils/audio.ts';

interface HeaderProps {
  activeTab: 'game' | 'levels' | 'howToPlay' | 'pedagogy' | 'glossary' | 'verify' | 'antigravity';
  setActiveTab: (tab: 'game' | 'levels' | 'howToPlay' | 'pedagogy' | 'glossary' | 'verify' | 'antigravity') => void;
  soundEnabled: boolean;
  setSoundEnabled: (v: boolean) => void;
  onResetPuzzle: () => void;
  currentPuzzleNumber: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  soundEnabled,
  setSoundEnabled,
  onResetPuzzle,
  currentPuzzleNumber
}) => {
  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    sound.enabled = next;
    if (next) sound.playTap();
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => {
            setActiveTab('game');
            sound.playTap();
          }}
          className="text-left group cursor-pointer focus:outline-none"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 font-bold text-base shadow-sm ring-1 ring-amber-400/40">
              VCT
            </div>
            <div>
              <span className="text-base sm:text-lg font-bold tracking-tight text-white group-hover:text-amber-400 transition-colors block leading-tight">
                Teka-Teki Silang PPKn
              </span>
              <span className="text-[11px] text-slate-400 font-normal hidden sm:block">
                Mahasiswa · Dosen · Peneliti Karakter Bangsa
              </span>
            </div>
          </div>
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden xl:flex items-center gap-5 text-xs font-medium text-slate-400">
          <button
            onClick={() => { setActiveTab('game'); sound.playTap(); }}
            className={`cursor-pointer transition-colors hover:text-white ${activeTab === 'game' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''}`}
          >
            Main TTS (Tipe {currentPuzzleNumber})
          </button>
          <button
            onClick={() => { setActiveTab('levels'); sound.playTap(); }}
            className={`cursor-pointer transition-colors hover:text-white ${activeTab === 'levels' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''}`}
          >
            10 Tipe Bentuk Buku
          </button>
          <button
            onClick={() => { setActiveTab('verify'); sound.playTap(); }}
            className={`cursor-pointer transition-colors hover:text-white ${activeTab === 'verify' ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400 pb-1' : ''}`}
          >
            Verifikasi Soal (50 Butir)
          </button>
          <button
            onClick={() => { setActiveTab('antigravity'); sound.playTap(); }}
            className={`cursor-pointer transition-colors hover:text-white ${activeTab === 'antigravity' ? 'text-blue-400 font-semibold border-b-2 border-blue-400 pb-1' : ''}`}
          >
            Inspeksi & Antigravity
          </button>
          <button
            onClick={() => { setActiveTab('pedagogy'); sound.playTap(); }}
            className={`cursor-pointer transition-colors hover:text-white ${activeTab === 'pedagogy' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''}`}
          >
            Saran & Panduan Dosen
          </button>
          <button
            onClick={() => { setActiveTab('howToPlay'); sound.playTap(); }}
            className={`cursor-pointer transition-colors hover:text-white ${activeTab === 'howToPlay' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''}`}
          >
            Logika & Cara Main
          </button>
          <button
            onClick={() => { setActiveTab('glossary'); sound.playTap(); }}
            className={`cursor-pointer transition-colors hover:text-white ${activeTab === 'glossary' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''}`}
          >
            Glosarium VCT
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {activeTab === 'game' && (
            <button
              onClick={() => {
                if (window.confirm('Reset semua huruf pada teka-teki silang ini?')) {
                  onResetPuzzle();
                  sound.playTap();
                }
              }}
              title="Reset Kotak Jawaban"
              className="p-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4 text-slate-400" />
              <span className="hidden md:inline">Reset</span>
            </button>
          )}

          <button
            onClick={toggleSound}
            title={soundEnabled ? 'Matikan Suara' : 'Nyalakan Suara'}
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            aria-label="Toggle Sound"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-amber-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>

          <button
            onClick={() => {
              setActiveTab(activeTab === 'verify' ? 'game' : 'verify');
              sound.playTap();
            }}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors whitespace-nowrap shadow-sm cursor-pointer flex items-center gap-1.5"
          >
            <BookOpen className="w-3.5 h-3.5 text-slate-950" />
            <span>Verifikasi Soal</span>
          </button>
        </div>
      </div>

      {/* Mobile / Tablet nav strip */}
      <div className="xl:hidden flex items-center gap-1 border-t border-slate-800/80 px-2 py-1.5 bg-slate-900/90 text-xs text-slate-400 overflow-x-auto">
        <button
          onClick={() => { setActiveTab('game'); sound.playTap(); }}
          className={`px-2 py-1 whitespace-nowrap rounded ${activeTab === 'game' ? 'text-amber-400 font-semibold bg-slate-800' : ''}`}
        >
          Main TTS
        </button>
        <button
          onClick={() => { setActiveTab('levels'); sound.playTap(); }}
          className={`px-2 py-1 whitespace-nowrap rounded ${activeTab === 'levels' ? 'text-amber-400 font-semibold bg-slate-800' : ''}`}
        >
          10 Tipe
        </button>
        <button
          onClick={() => { setActiveTab('verify'); sound.playTap(); }}
          className={`px-2 py-1 whitespace-nowrap rounded ${activeTab === 'verify' ? 'text-emerald-400 font-semibold bg-slate-800' : ''}`}
        >
          Verifikasi Soal
        </button>
        <button
          onClick={() => { setActiveTab('antigravity'); sound.playTap(); }}
          className={`px-2 py-1 whitespace-nowrap rounded ${activeTab === 'antigravity' ? 'text-blue-400 font-semibold bg-slate-800' : ''}`}
        >
          Antigravity
        </button>
        <button
          onClick={() => { setActiveTab('pedagogy'); sound.playTap(); }}
          className={`px-2 py-1 whitespace-nowrap rounded ${activeTab === 'pedagogy' ? 'text-amber-400 font-semibold bg-slate-800' : ''}`}
        >
          Saran Dosen
        </button>
        <button
          onClick={() => { setActiveTab('howToPlay'); sound.playTap(); }}
          className={`px-2 py-1 whitespace-nowrap rounded ${activeTab === 'howToPlay' ? 'text-amber-400 font-semibold bg-slate-800' : ''}`}
        >
          Cara Main
        </button>
        <button
          onClick={() => { setActiveTab('glossary'); sound.playTap(); }}
          className={`px-2 py-1 whitespace-nowrap rounded ${activeTab === 'glossary' ? 'text-amber-400 font-semibold bg-slate-800' : ''}`}
        >
          Glosarium
        </button>
      </div>
    </header>
  );
};
