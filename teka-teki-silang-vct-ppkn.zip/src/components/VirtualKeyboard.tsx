import React from 'react';
import { Delete, ArrowRight, ArrowDown, Lightbulb } from 'lucide-react';
import { sound } from '../utils/audio.ts';
import { Direction } from '../data/types.ts';

interface VirtualKeyboardProps {
  onKeyPress: (char: string) => void;
  onBackspace: () => void;
  onToggleDirection: () => void;
  onHint: () => void;
  currentDirection: Direction;
  canHint: boolean;
}

const KEYBOARD_ROWS = [
  ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
  ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
  ['Z', 'X', 'C', 'V', 'B', 'N', 'M']
];

export const VirtualKeyboard: React.FC<VirtualKeyboardProps> = ({
  onKeyPress,
  onBackspace,
  onToggleDirection,
  onHint,
  currentDirection,
  canHint,
}) => {
  return (
    <div className="w-full max-w-xl mx-auto p-2 sm:p-3 bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl select-none">
      <div className="flex flex-col gap-1.5 sm:gap-2">
        {/* Row 1 */}
        <div className="flex justify-center gap-1 sm:gap-1.5">
          {KEYBOARD_ROWS[0].map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => {
                onKeyPress(k);
                sound.playTap();
              }}
              className="h-10 sm:h-12 flex-1 max-w-[44px] rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 text-white font-mono font-bold text-sm sm:text-base border border-slate-700 shadow-sm transition-colors cursor-pointer flex items-center justify-center"
            >
              {k}
            </button>
          ))}
        </div>

        {/* Row 2 */}
        <div className="flex justify-center gap-1 sm:gap-1.5 px-3">
          {KEYBOARD_ROWS[1].map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => {
                onKeyPress(k);
                sound.playTap();
              }}
              className="h-10 sm:h-12 flex-1 max-w-[44px] rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 text-white font-mono font-bold text-sm sm:text-base border border-slate-700 shadow-sm transition-colors cursor-pointer flex items-center justify-center"
            >
              {k}
            </button>
          ))}
        </div>

        {/* Row 3 with special action buttons */}
        <div className="flex justify-center gap-1 sm:gap-1.5">
          {/* Toggle Direction button */}
          <button
            type="button"
            onClick={() => {
              onToggleDirection();
              sound.playTap();
            }}
            title="Ganti arah (Mendatar / Menurun)"
            className="h-10 sm:h-12 px-2.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-amber-300 font-medium text-xs border border-slate-700 shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-1"
          >
            {currentDirection === 'across' ? (
              <>
                <ArrowRight className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Mendatar</span>
              </>
            ) : (
              <>
                <ArrowDown className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Menurun</span>
              </>
            )}
          </button>

          {KEYBOARD_ROWS[2].map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => {
                onKeyPress(k);
                sound.playTap();
              }}
              className="h-10 sm:h-12 flex-1 max-w-[44px] rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 text-white font-mono font-bold text-sm sm:text-base border border-slate-700 shadow-sm transition-colors cursor-pointer flex items-center justify-center"
            >
              {k}
            </button>
          ))}

          {/* Backspace button */}
          <button
            type="button"
            onClick={() => {
              onBackspace();
              sound.playTap();
            }}
            title="Hapus Huruf"
            className="h-10 sm:h-12 px-3 rounded-lg bg-slate-800 hover:bg-rose-950/50 hover:text-rose-300 text-slate-300 border border-slate-700 shadow-sm transition-colors cursor-pointer flex items-center justify-center"
          >
            <Delete className="w-4 h-4" />
          </button>

          {/* Hint button */}
          <button
            type="button"
            disabled={!canHint}
            onClick={() => {
              onHint();
            }}
            title="Buka 1 Huruf (-15 poin)"
            className={`h-10 sm:h-12 px-2.5 rounded-lg border shadow-sm transition-colors flex items-center justify-center gap-1 cursor-pointer ${
              canHint
                ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/40'
                : 'bg-slate-800/40 text-slate-600 border-slate-800 cursor-not-allowed'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span className="text-[11px] font-medium hidden sm:inline">Petunjuk</span>
          </button>
        </div>
      </div>
    </div>
  );
};
