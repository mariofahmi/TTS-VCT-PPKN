import React from 'react';
import { Direction, Puzzle, WordItem } from '../data/types.ts';

interface CrosswordGridProps {
  puzzle: Puzzle;
  userGrid: string[][];
  selectedCell: { row: number; col: number } | null;
  selectedDirection: Direction;
  selectedWord: WordItem | null;
  onCellClick: (row: number, col: number) => void;
  showErrors: boolean;
  isComplete: boolean;
}

export const CrosswordGrid: React.FC<CrosswordGridProps> = ({
  puzzle,
  userGrid,
  selectedCell,
  selectedDirection,
  selectedWord,
  onCellClick,
  showErrors,
  isComplete,
}) => {
  // Pre-calculate cell numbers and valid cells
  const validCells = React.useMemo(() => {
    const valid = new Set<string>();
    puzzle.words.forEach(w => {
      const len = w.word.length;
      for (let i = 0; i < len; i++) {
        const r = w.direction === 'across' ? w.row : w.row + i;
        const c = w.direction === 'across' ? w.col + i : w.col;
        valid.add(`${r},${c}`);
      }
    });
    return valid;
  }, [puzzle]);

  const cellNumbers = React.useMemo(() => {
    const numbers = new Map<string, number>();
    puzzle.words.forEach(w => {
      const key = `${w.row},${w.col}`;
      if (!numbers.has(key)) {
        numbers.set(key, w.number);
      }
    });
    return numbers;
  }, [puzzle]);

  // Solution map to check errors
  const solutionMap = React.useMemo(() => {
    const map = new Map<string, string>();
    puzzle.words.forEach(w => {
      for (let i = 0; i < w.word.length; i++) {
        const r = w.direction === 'across' ? w.row : w.row + i;
        const c = w.direction === 'across' ? w.col + i : w.col;
        map.set(`${r},${c}`, w.word[i]);
      }
    });
    return map;
  }, [puzzle]);

  // Active word coordinates
  const activeWordCells = React.useMemo(() => {
    const set = new Set<string>();
    if (!selectedWord) return set;
    for (let i = 0; i < selectedWord.word.length; i++) {
      const r = selectedWord.direction === 'across' ? selectedWord.row : selectedWord.row + i;
      const c = selectedWord.direction === 'across' ? selectedWord.col + i : selectedWord.col;
      set.add(`${r},${c}`);
    }
    return set;
  }, [selectedWord]);

  return (
    <div className="w-full flex justify-center items-center p-2 sm:p-4 bg-slate-900/60 rounded-2xl border border-slate-800 shadow-inner overflow-x-auto">
      <div
        className="grid gap-1 sm:gap-1.5 p-2 bg-slate-950/80 rounded-xl border border-slate-800 shadow-2xl select-none"
        style={{
          gridTemplateColumns: `repeat(${puzzle.cols}, minmax(0, 1fr))`,
          width: 'max-content'
        }}
      >
        {Array.from({ length: puzzle.rows }).map((_, r) =>
          Array.from({ length: puzzle.cols }).map((_, c) => {
            const key = `${r},${c}`;
            const isValid = validCells.has(key);
            const num = cellNumbers.get(key);
            const currentLetter = userGrid[r]?.[c] || '';
            const isSelected = selectedCell?.row === r && selectedCell?.col === c;
            const isInActiveWord = activeWordCells.has(key);
            const expectedLetter = solutionMap.get(key);
            const isError = showErrors && currentLetter !== '' && currentLetter !== expectedLetter;
            const isCorrect = currentLetter !== '' && currentLetter === expectedLetter;

            if (!isValid) {
              return (
                <div
                  key={key}
                  className="w-8 h-8 sm:w-11 sm:h-11 rounded-md bg-slate-950/90 border border-slate-900/60"
                  aria-hidden="true"
                />
              );
            }

            return (
              <button
                key={key}
                type="button"
                onClick={() => onCellClick(r, c)}
                className={`w-8 h-8 sm:w-11 sm:h-11 relative flex items-center justify-center rounded-lg font-bold text-base sm:text-xl transition-all duration-150 cursor-pointer focus:outline-none ${
                  isSelected
                    ? 'bg-amber-400 text-slate-950 ring-2 sm:ring-4 ring-amber-400/50 shadow-lg scale-[1.03] z-20'
                    : isInActiveWord
                    ? 'bg-amber-950/40 text-amber-200 border-2 border-amber-500/50 z-10'
                    : isComplete
                    ? 'bg-emerald-950/30 text-emerald-300 border border-emerald-500/40'
                    : isError
                    ? 'bg-rose-950/50 text-rose-300 border-2 border-rose-500 animate-pulse'
                    : currentLetter
                    ? 'bg-slate-800/90 text-white border border-slate-700 hover:border-slate-600'
                    : 'bg-slate-800/50 text-slate-300 border border-slate-700/80 hover:bg-slate-700/60'
                }`}
              >
                {/* Clue Number Indicator */}
                {num !== undefined && (
                  <span
                    className={`absolute top-0.5 left-1 text-[8px] sm:text-[10px] font-mono leading-none font-bold ${
                      isSelected ? 'text-slate-900/80' : 'text-slate-400'
                    }`}
                  >
                    {num}
                  </span>
                )}

                {/* Displayed User Letter */}
                <span className="font-mono mt-0.5 sm:mt-1">{currentLetter}</span>

                {/* Correct subtle green dot in non-selected filled cell */}
                {isCorrect && !isSelected && !isInActiveWord && !isComplete && (
                  <span className="absolute bottom-0.5 right-1 w-1.5 h-1.5 rounded-full bg-emerald-500/60" />
                )}
              </button>
            );
          })
        )}
      </div>
    </div>
  );
};
