import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { puzzles } from './data/puzzles.ts';
import { Direction, Puzzle, WordItem, VctReflectionOption } from './data/types.ts';
import { Header } from './components/Header.tsx';
import { CrosswordGrid } from './components/CrosswordGrid.tsx';
import { ClueList } from './components/ClueList.tsx';
import { VirtualKeyboard } from './components/VirtualKeyboard.tsx';
import { PuzzleSelector } from './components/PuzzleSelector.tsx';
import { VctReflectionModal } from './components/VctReflectionModal.tsx';
import { PlayerLogicGuide } from './components/PlayerLogicGuide.tsx';
import { PedagogicalAdvice } from './components/PedagogicalAdvice.tsx';
import { GlossaryView } from './components/GlossaryView.tsx';
import { AcademicVerificationView } from './components/AcademicVerificationView.tsx';
import { AntigravityExportView } from './components/AntigravityExportView.tsx';
import { sound } from './utils/audio.ts';
import { 
  CheckCircle, 
  Lightbulb, 
  Timer as TimerIcon, 
  Trophy, 
  Eye, 
  BookOpen, 
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Flame,
  Info
} from 'lucide-react';

const STORAGE_KEY = 'vct_crossword_stats_v1';

export default function App() {
  const [activeTab, setActiveTab] = useState<'game' | 'levels' | 'howToPlay' | 'pedagogy' | 'glossary' | 'verify' | 'antigravity'>('game');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Active puzzle state
  const [currentPuzzleId, setCurrentPuzzleId] = useState<string>(puzzles[0].id);
  const currentPuzzle = useMemo(
    () => puzzles.find((p) => p.id === currentPuzzleId) || puzzles[0],
    [currentPuzzleId]
  );

  // Grid letters state
  const [userGrid, setUserGrid] = useState<string[][]>(() =>
    Array.from({ length: currentPuzzle.rows }, () => Array(currentPuzzle.cols).fill(''))
  );

  // Navigation & selection state
  const [selectedCell, setSelectedCell] = useState<{ row: number; col: number } | null>(null);
  const [selectedDirection, setSelectedDirection] = useState<Direction>('across');
  const [showErrors, setShowErrors] = useState(false);
  const [showVictoryModal, setShowVictoryModal] = useState(false);
  const [gameMode, setGameMode] = useState<'santai' | 'ujian'>('santai');

  // Metrics
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [score, setScore] = useState(0);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [streak, setStreak] = useState(0);

  // Stats storage
  const [completedStats, setCompletedStats] = useState<Record<string, { completed: boolean; stars: number; score: number }>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Reset grid when puzzle changes
  useEffect(() => {
    setUserGrid(Array.from({ length: currentPuzzle.rows }, () => Array(currentPuzzle.cols).fill('')));
    // Pick first word as selected
    const firstWord = currentPuzzle.words[0];
    if (firstWord) {
      setSelectedCell({ row: firstWord.row, col: firstWord.col });
      setSelectedDirection(firstWord.direction);
    }
    setTimerSeconds(0);
    setIsTimerRunning(true);
    setScore(0);
    setHintsUsed(0);
    setStreak(0);
    setShowErrors(false);
    setShowVictoryModal(false);
  }, [currentPuzzleId, currentPuzzle]);

  // Timer loop
  useEffect(() => {
    if (!isTimerRunning || showVictoryModal) return;
    const interval = setInterval(() => {
      setTimerSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isTimerRunning, showVictoryModal]);

  // Filter across & down words
  const acrossWords = useMemo(
    () => currentPuzzle.words.filter((w) => w.direction === 'across'),
    [currentPuzzle]
  );
  const downWords = useMemo(
    () => currentPuzzle.words.filter((w) => w.direction === 'down'),
    [currentPuzzle]
  );

  // Compute selected word based on selected cell & direction
  const selectedWord = useMemo<WordItem | null>(() => {
    if (!selectedCell) return null;
    const { row, col } = selectedCell;

    // Check preferred direction first
    const match = currentPuzzle.words.find((w) => {
      if (w.direction !== selectedDirection) return false;
      if (w.direction === 'across') {
        return w.row === row && col >= w.col && col < w.col + w.word.length;
      } else {
        return w.col === col && row >= w.row && row < w.row + w.word.length;
      }
    });

    if (match) return match;

    // Fallback to other direction
    return (
      currentPuzzle.words.find((w) => {
        if (w.direction === 'across') {
          return w.row === row && col >= w.col && col < w.col + w.word.length;
        } else {
          return w.col === col && row >= w.row && row < w.row + w.word.length;
        }
      }) || null
    );
  }, [currentPuzzle, selectedCell, selectedDirection]);

  // Keep selectedDirection aligned with active word
  useEffect(() => {
    if (selectedWord && selectedWord.direction !== selectedDirection) {
      setSelectedDirection(selectedWord.direction);
    }
  }, [selectedWord, selectedDirection]);

  // Check which words are completely and correctly filled
  const completedWordIds = useMemo(() => {
    const completed = new Set<string>();
    currentPuzzle.words.forEach((w) => {
      let isWordComplete = true;
      for (let i = 0; i < w.word.length; i++) {
        const r = w.direction === 'across' ? w.row : w.row + i;
        const c = w.direction === 'across' ? w.col + i : w.col;
        if (userGrid[r]?.[c] !== w.word[i]) {
          isWordComplete = false;
          break;
        }
      }
      if (isWordComplete) completed.add(w.id);
    });
    return completed;
  }, [currentPuzzle, userGrid]);

  // Check overall puzzle completion
  const isEntirePuzzleComplete = useMemo(() => {
    return (
      completedWordIds.size === currentPuzzle.words.length &&
      currentPuzzle.words.length > 0
    );
  }, [completedWordIds, currentPuzzle]);

  // Trigger victory modal when complete
  useEffect(() => {
    if (isEntirePuzzleComplete && !showVictoryModal) {
      setIsTimerRunning(false);
      setShowVictoryModal(true);

      // Save stats
      const starsEarned = hintsUsed === 0 ? 3 : hintsUsed <= 2 ? 2 : 1;
      const finalScore = Math.max(100, score + 200 - hintsUsed * 20);
      setScore(finalScore);

      setCompletedStats((prev) => {
        const updated = {
          ...prev,
          [currentPuzzle.id]: {
            completed: true,
            stars: Math.max(prev[currentPuzzle.id]?.stars || 0, starsEarned),
            score: Math.max(prev[currentPuzzle.id]?.score || 0, finalScore)
          }
        };
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        } catch {}
        return updated;
      });
    }
  }, [isEntirePuzzleComplete, showVictoryModal, hintsUsed, score, currentPuzzle]);

  // Cell Click Handler
  const handleCellClick = useCallback(
    (row: number, col: number) => {
      sound.playTap();
      if (selectedCell?.row === row && selectedCell?.col === col) {
        // Toggle direction if cell is part of both directions
        const hasAcross = currentPuzzle.words.some(
          (w) => w.direction === 'across' && w.row === row && col >= w.col && col < w.col + w.word.length
        );
        const hasDown = currentPuzzle.words.some(
          (w) => w.direction === 'down' && w.col === col && row >= w.row && row < w.row + w.word.length
        );
        if (hasAcross && hasDown) {
          setSelectedDirection((prev) => (prev === 'across' ? 'down' : 'across'));
        }
      } else {
        setSelectedCell({ row, col });
        // Check if current direction contains this cell; if not, flip
        const fitsCurrentDir = currentPuzzle.words.some((w) => {
          if (w.direction !== selectedDirection) return false;
          if (w.direction === 'across') {
            return w.row === row && col >= w.col && col < w.col + w.word.length;
          } else {
            return w.col === col && row >= w.row && row < w.row + w.word.length;
          }
        });
        if (!fitsCurrentDir) {
          setSelectedDirection((prev) => (prev === 'across' ? 'down' : 'across'));
        }
      }
    },
    [selectedCell, selectedDirection, currentPuzzle]
  );

  // Move cursor forward in current word
  const advanceCursor = useCallback(
    (startRow: number, startCol: number, dir: Direction) => {
      if (!selectedWord) return;
      const len = selectedWord.word.length;
      const idx = dir === 'across' ? startCol - selectedWord.col : startRow - selectedWord.row;
      if (idx + 1 < len) {
        const nextR = dir === 'across' ? selectedWord.row : selectedWord.row + idx + 1;
        const nextC = dir === 'across' ? selectedWord.col + idx + 1 : selectedWord.col;
        setSelectedCell({ row: nextR, col: nextC });
      }
    },
    [selectedWord]
  );

  // Move cursor backward
  const retreatCursor = useCallback(
    (startRow: number, startCol: number, dir: Direction) => {
      if (!selectedWord) return;
      const idx = dir === 'across' ? startCol - selectedWord.col : startRow - selectedWord.row;
      if (idx > 0) {
        const prevR = dir === 'across' ? selectedWord.row : selectedWord.row + idx - 1;
        const prevC = dir === 'across' ? selectedWord.col + idx - 1 : selectedWord.col;
        setSelectedCell({ row: prevR, col: prevC });
      }
    },
    [selectedWord]
  );

  // Character Input Handler
  const handleInputChar = useCallback(
    (char: string) => {
      if (!selectedCell || !selectedWord) return;
      const letter = char.toUpperCase();
      if (!/^[A-Z]$/.test(letter)) return;

      const { row, col } = selectedCell;
      const prevChar = userGrid[row]?.[col] || '';

      setUserGrid((prev) => {
        const next = prev.map((r) => [...r]);
        next[row][col] = letter;
        return next;
      });

      // Score bonus for letter
      setScore((s) => s + (prevChar === '' ? 15 : 5));
      setStreak((st) => st + 1);

      // Check if this newly fills a word correctly
      const expectedChar = selectedWord.word[
        selectedDirection === 'across' ? col - selectedWord.col : row - selectedWord.row
      ];
      if (letter === expectedChar) {
        sound.playTap();
      }

      advanceCursor(row, col, selectedDirection);
    },
    [selectedCell, selectedWord, userGrid, selectedDirection, advanceCursor]
  );

  // Backspace Handler
  const handleBackspace = useCallback(() => {
    if (!selectedCell || !selectedWord) return;
    const { row, col } = selectedCell;
    const currentVal = userGrid[row]?.[col] || '';

    if (currentVal !== '') {
      setUserGrid((prev) => {
        const next = prev.map((r) => [...r]);
        next[row][col] = '';
        return next;
      });
    } else {
      retreatCursor(row, col, selectedDirection);
      const idx = selectedDirection === 'across' ? col - selectedWord.col - 1 : row - selectedWord.row - 1;
      if (idx >= 0) {
        const targetR = selectedDirection === 'across' ? selectedWord.row : selectedWord.row + idx;
        const targetC = selectedDirection === 'across' ? selectedWord.col + idx : selectedWord.col;
        setUserGrid((prev) => {
          const next = prev.map((r) => [...r]);
          next[targetR][targetC] = '';
          return next;
        });
      }
    }
  }, [selectedCell, selectedWord, userGrid, selectedDirection, retreatCursor]);

  // Physical Keyboard Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't capture when typing in inputs/search bars
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        if (selectedCell && selectedCell.col + 1 < currentPuzzle.cols) {
          handleCellClick(selectedCell.row, selectedCell.col + 1);
        }
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        if (selectedCell && selectedCell.col - 1 >= 0) {
          handleCellClick(selectedCell.row, selectedCell.col - 1);
        }
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (selectedCell && selectedCell.row + 1 < currentPuzzle.rows) {
          handleCellClick(selectedCell.row + 1, selectedCell.col);
        }
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (selectedCell && selectedCell.row - 1 >= 0) {
          handleCellClick(selectedCell.row - 1, selectedCell.col);
        }
      } else if (e.key === ' ' || e.key === 'Tab') {
        e.preventDefault();
        setSelectedDirection((d) => (d === 'across' ? 'down' : 'across'));
        sound.playTap();
      } else if (/^[a-zA-Z]$/.test(e.key)) {
        e.preventDefault();
        handleInputChar(e.key);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedCell, currentPuzzle, handleBackspace, handleCellClick, handleInputChar]);

  // Select Word from Clue List
  const handleSelectWord = useCallback((w: WordItem) => {
    sound.playTap();
    setSelectedDirection(w.direction);
    setSelectedCell({ row: w.row, col: w.col });
  }, []);

  // Hint: Reveal Current Cell
  const handleHint = useCallback(() => {
    if (!selectedCell || !selectedWord) return;
    const { row, col } = selectedCell;
    const idx = selectedDirection === 'across' ? col - selectedWord.col : row - selectedWord.row;
    const correctLetter = selectedWord.word[idx];

    if (correctLetter) {
      setUserGrid((prev) => {
        const next = prev.map((r) => [...r]);
        next[row][col] = correctLetter;
        return next;
      });
      setHintsUsed((h) => h + 1);
      setScore((s) => Math.max(0, s - 15));
      sound.playHint();
      advanceCursor(row, col, selectedDirection);
    }
  }, [selectedCell, selectedWord, selectedDirection, advanceCursor]);

  // Check Errors Button
  const handleCheckErrors = useCallback(() => {
    setShowErrors(true);
    sound.playTap();
    setTimeout(() => {
      setShowErrors(false);
    }, 2500);
  }, []);

  // Reset current puzzle
  const handleResetPuzzle = useCallback(() => {
    setUserGrid(Array.from({ length: currentPuzzle.rows }, () => Array(currentPuzzle.cols).fill('')));
    setScore(0);
    setHintsUsed(0);
    setStreak(0);
    setShowErrors(false);
    const firstWord = currentPuzzle.words[0];
    if (firstWord) {
      setSelectedCell({ row: firstWord.row, col: firstWord.col });
      setSelectedDirection(firstWord.direction);
    }
  }, [currentPuzzle]);

  // Next Puzzle
  const handleNextPuzzle = useCallback(() => {
    const currentIndex = puzzles.findIndex((p) => p.id === currentPuzzleId);
    const nextIndex = (currentIndex + 1) % puzzles.length;
    setCurrentPuzzleId(puzzles[nextIndex].id);
    setShowVictoryModal(false);
    sound.playTap();
  }, [currentPuzzleId]);

  // Prev Puzzle
  const handlePrevPuzzle = useCallback(() => {
    const currentIndex = puzzles.findIndex((p) => p.id === currentPuzzleId);
    const prevIndex = (currentIndex - 1 + puzzles.length) % puzzles.length;
    setCurrentPuzzleId(puzzles[prevIndex].id);
    sound.playTap();
  }, [currentPuzzleId]);

  const formatTimer = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        onResetPuzzle={handleResetPuzzle}
        currentPuzzleNumber={currentPuzzle.typeNumber}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'game' && (
          <div className="space-y-6">
            {/* HUD / Top Control Bar */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-3 sm:p-4 shadow-md flex flex-wrap items-center justify-between gap-3">
              {/* Type Switcher & Title */}
              <div className="flex items-center gap-2 sm:gap-3">
                <button
                  onClick={handlePrevPuzzle}
                  title="Tipe Sebelumnya"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-md">
                      Tipe #{currentPuzzle.typeNumber} / 10
                    </span>
                    <span className="text-xs text-slate-400 font-medium hidden sm:inline">
                      {currentPuzzle.category}
                    </span>
                  </div>
                  <h1 className="text-sm sm:text-base font-bold text-white tracking-tight leading-tight">
                    {currentPuzzle.title}
                  </h1>
                </div>

                <button
                  onClick={handleNextPuzzle}
                  title="Tipe Selanjutnya"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Stats: Score, Timer, Words Completed */}
              <div className="flex items-center gap-3 sm:gap-5 text-xs">
                <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800/80">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  <span className="font-mono font-bold text-amber-300">{score}</span>
                  <span className="text-slate-400 hidden sm:inline">Poin</span>
                </div>

                <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800/80">
                  <TimerIcon className="w-4 h-4 text-slate-400" />
                  <span className="font-mono font-bold text-white">{formatTimer(timerSeconds)}</span>
                </div>

                <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800/80">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span className="font-mono font-bold text-emerald-300">
                    {completedWordIds.size} / {currentPuzzle.words.length}
                  </span>
                  <span className="text-slate-400 hidden sm:inline">Kata</span>
                </div>

                {streak > 3 && (
                  <div className="hidden md:flex items-center gap-1 bg-amber-500/20 text-amber-300 px-2.5 py-1 rounded-xl text-xs font-semibold animate-pulse">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span>Streak {streak}x</span>
                  </div>
                )}
              </div>

              {/* Actions: Cek Jawaban & Bantuan */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCheckErrors}
                  className="px-3 py-1.5 text-xs font-medium rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5 text-slate-400" />
                  <span>Cek Huruf</span>
                </button>

                <button
                  type="button"
                  onClick={handleHint}
                  disabled={!selectedCell}
                  className={`px-3 py-1.5 text-xs font-medium rounded-xl border transition-colors cursor-pointer flex items-center gap-1.5 ${
                    selectedCell
                      ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-500/50'
                      : 'bg-slate-800/40 text-slate-600 border-slate-800 cursor-not-allowed'
                  }`}
                >
                  <Lightbulb className="w-3.5 h-3.5" />
                  <span>Buka Huruf</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setActiveTab('verify'); sound.playTap(); }}
                  title="Lihat Kunci & Validitas Akademik"
                  className="hidden sm:flex px-3 py-1.5 text-xs font-semibold rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 transition-colors cursor-pointer items-center gap-1.5"
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Audit Soal</span>
                </button>
              </div>
            </div>

            {/* Active Word Clue Banner */}
            {selectedWord && (
              <div className="p-3 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 rounded-2xl border border-amber-500/40 shadow-sm flex items-start gap-3">
                <div className="w-7 h-7 rounded-lg bg-amber-400 text-slate-950 font-bold font-mono text-xs flex items-center justify-center shrink-0 mt-0.5">
                  {selectedWord.number}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-semibold text-amber-300 uppercase tracking-wider">
                      {selectedWord.direction === 'across' ? 'Mendatar' : 'Menurun'} ({selectedWord.word.length} Huruf)
                    </span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-400 text-[11px] truncate flex items-center gap-1">
                      <BookOpen className="w-3 h-3 text-amber-400/80" />
                      {selectedWord.bookRef}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-200 mt-1 leading-snug font-medium">
                    {selectedWord.clue}
                  </p>
                </div>
              </div>
            )}

            {/* Main Game Stage: Left Grid, Right Clues */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Grid & Virtual Keyboard */}
              <div className="lg:col-span-7 space-y-4">
                <CrosswordGrid
                  puzzle={currentPuzzle}
                  userGrid={userGrid}
                  selectedCell={selectedCell}
                  selectedDirection={selectedDirection}
                  selectedWord={selectedWord}
                  onCellClick={handleCellClick}
                  showErrors={showErrors}
                  isComplete={isEntirePuzzleComplete}
                />

                {/* Book Quote / Thought Card */}
                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 italic flex items-start gap-2.5">
                  <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-medium text-slate-200 not-italic block mb-0.5">Kutipan Sumber Buku:</span>
                    {currentPuzzle.quote}
                  </div>
                </div>

                {/* Virtual Keyboard */}
                <VirtualKeyboard
                  onKeyPress={handleInputChar}
                  onBackspace={handleBackspace}
                  onToggleDirection={() => {
                    setSelectedDirection((d) => (d === 'across' ? 'down' : 'across'));
                  }}
                  onHint={handleHint}
                  currentDirection={selectedDirection}
                  canHint={Boolean(selectedCell)}
                />
              </div>

              {/* Right Column: Clue List */}
              <div className="lg:col-span-5">
                <ClueList
                  acrossWords={acrossWords}
                  downWords={downWords}
                  selectedWord={selectedWord}
                  onSelectWord={handleSelectWord}
                  completedWordIds={completedWordIds}
                />
              </div>
            </div>
          </div>
        )}

        {/* 10 Types Tab */}
        {activeTab === 'levels' && (
          <PuzzleSelector
            puzzles={puzzles}
            currentPuzzleId={currentPuzzleId}
            onSelectPuzzle={(id) => {
              setCurrentPuzzleId(id);
              setActiveTab('game');
            }}
            completedStats={completedStats}
          />
        )}

        {/* How To Play & Player Logic Tab */}
        {activeTab === 'howToPlay' && <PlayerLogicGuide />}

        {/* Academic Questions Verification Tab */}
        {activeTab === 'verify' && <AcademicVerificationView />}

        {/* Antigravity Architecture & JSON Inspector Tab */}
        {activeTab === 'antigravity' && <AntigravityExportView />}

        {/* Pedagogical Advice for Teachers Tab */}
        {activeTab === 'pedagogy' && <PedagogicalAdvice />}

        {/* Glossary Tab */}
        {activeTab === 'glossary' && <GlossaryView />}
      </main>

      {/* Victory and Reflection Dialog */}
      {showVictoryModal && (
        <VctReflectionModal
          puzzle={currentPuzzle}
          score={score}
          timeSpent={timerSeconds}
          hintsUsed={hintsUsed}
          onNextPuzzle={handleNextPuzzle}
          onClose={() => setShowVictoryModal(false)}
          onSaveReflection={(selectedOption: VctReflectionOption) => {
            console.log('User completed VCT reflection:', selectedOption);
          }}
        />
      )}

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-900 bg-slate-950/80 py-4 text-center text-xs text-slate-400 px-4">
        <p>
          Media Pembelajaran Teka-Teki Silang PPKn Berbasis Value Clarification Technique (VCT) · Sumber Rujukan: Dr. Sukisno, M.Pd., Mario Fahmi Syahrial, M.Pd., dkk. (Yudharta Press, 2026, ISBN: 978-623-7817-62-8)
        </p>
      </footer>
    </div>
  );
}
